package com.cg.fms.controller;


import java.util.List;




import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.service.IFmsService;

@Controller
public class FmsController 
{
	@Autowired
	IFmsService fmsservice;

	@RequestMapping(value="all", method=RequestMethod.GET)
	public String getAll(Model model)
	{

		List<Long> empIds = fmsservice.getAllEmployeeIds();
		model.addAttribute("eIdList", empIds);
		model.addAttribute("my", new EmployeeBean());

		return "login";
	}
	@RequestMapping(value="feedbackform", method=RequestMethod.GET)
	public String inHome(@Valid @ModelAttribute("my")EmployeeBean emp,BindingResult result,Model model)
	{
		if(result.hasErrors()){}	
		else{
		EmployeeBean employee=fmsservice.RetrieveEmployeeDetail(emp.getEmployeeId());
		if(emp.getPassword().equalsIgnoreCase(employee.getPassword()))
		{
			String role=employee.getRole();
			switch (role) 
			{
			case "Admin":
				return "admin";

			case "Coordinator":		
				return "coordinator";

			case "Participant":
				model.addAttribute("empId", emp.getEmployeeId());
				model.addAttribute("my", new FeedbackBean());
				List<Long> getTrainingIds=fmsservice.getAllTrainingCode(emp.getEmployeeId());
				model.addAttribute("trainingIdList", getTrainingIds);
				return "FeedbackForm";
			}
		}
		}
		model.addAttribute("error", "Please provide valid password");
		List<Long> empIds = fmsservice.getAllEmployeeIds();
		model.addAttribute("eIdList", empIds);
		return "login";
	}
	@RequestMapping(value="validatefeedbackdetail", method=RequestMethod.POST)
	public ModelAndView sucess(@Valid @ModelAttribute("my")FeedbackBean feedback,BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("FeedbackForm");
		}
		else
		{	
			if(fmsservice.validateFeedback(feedback.getTrainingCode(), feedback.getParticipantId()))
			{
				FeedbackBean feedback1=fmsservice.insertFeedbackDetail(feedback);
				mv.addObject("feedback", feedback1);
				mv.setViewName("sucess");
			}
			else
			{
				mv.addObject("error1","Participant has already filled the Feedback Form");
				mv.setViewName("FeedbackForm");
			}			
		}

		List<Long> getTrainingIds=fmsservice.getAllTrainingCode(feedback.getParticipantId());
		mv.addObject("trainingIdList", getTrainingIds);
		return mv;
	}
	@RequestMapping(value="viewOptions",method=RequestMethod.GET)
	public String viewOptions(@ModelAttribute("my")FeedbackBean feedback,Model model)
	{
		//ModelAndView mv = new ModelAndView();
		List<Long> tList=fmsservice.getAllFeedBackTrainingIds();
		List<Long> pList=fmsservice.getAllFeedBackParticipanIds();
		model.addAttribute("trainingList", tList);
		model.addAttribute("participantList", pList);
		//mv.setViewName("viewOptions");
		return "viewOptions";
	}
	@RequestMapping(value="viewByTrainingID",method=RequestMethod.POST)
	public ModelAndView viewByTrainingID(@ModelAttribute("my")FeedbackBean feedback)
	{
		ModelAndView mv = new ModelAndView();
		List<FeedbackBean> fList=fmsservice.getFeedbackByTrainingId(feedback.getTrainingCode());
		mv.addObject("feedbackList", fList);
		mv.setViewName("ViewReport");
		return mv;
	}
	@RequestMapping(value="viewByParticipantID",method=RequestMethod.POST)
	public ModelAndView viewByParticipantID(@ModelAttribute("my")FeedbackBean feedback)
	{
		ModelAndView mv = new ModelAndView();
		List<FeedbackBean> fList=fmsservice.getFeedbackByParticipantId(feedback.getParticipantId());
		mv.addObject("feedbackList", fList);
		mv.setViewName("ViewReport");
		return mv;
	}
}
