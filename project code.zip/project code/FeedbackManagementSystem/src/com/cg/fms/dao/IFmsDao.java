package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;


public interface IFmsDao 
{
	FeedbackBean insertFeedback(FeedbackBean feedback);
	List<Long> validateGetAllFeedBackTrainingIds();
	List<Long> validateGetAllFeedBackParticipanIds(long trainingId);
	List<FeedbackBean> getFeedbackByTrainingId(long trainingId);
	List<FeedbackBean> getFeedbackByParticipantId(long participantId);
	List<Long> getAllEmployeeIds();
	EmployeeBean RetrieveEmployeeDetail(long empId);
	List<Long> getAllTrainingCode(long participantId);
	List<Long> getAllFeedBackParticipanIds();
}
