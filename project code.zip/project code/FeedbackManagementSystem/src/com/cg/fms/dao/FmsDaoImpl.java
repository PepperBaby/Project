package com.cg.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;


@Repository("fmsdao")
public class FmsDaoImpl implements IFmsDao 
{
	@PersistenceContext
	EntityManager entitymanager;
	/*Insert Entered Feedback form details into Database*/
	@Override
	public FeedbackBean insertFeedback(FeedbackBean feedback) {
		entitymanager.persist(feedback);
		entitymanager.flush();	
		return feedback;
	}

	/*Retrieving all training Ids from Feedback_master for validation of 
	 * whether that Id has already given feedback or not*/
	@Override
	public List<Long> validateGetAllFeedBackTrainingIds()
	{
		String q2="SELECT fbean.trainingCode FROM FeedbackBean fbean";
		Query query2=entitymanager.createQuery(q2);
		return query2.getResultList();
	}
	/*Retrieving all Participant Ids from Feedback_master based on trainingId for 
	 * validation of whether that Id has already given feedback or not*/
	@Override
	public List<Long> validateGetAllFeedBackParticipanIds(long trainingId) 
	{
		String q="SELECT fbean.participantId FROM FeedbackBean fbean WHERE fbean.trainingCode =:trainingId";
		Query query=entitymanager.createQuery(q);
		query.setParameter("trainingId", trainingId);
		return query.getResultList();
	}
	
	/*Retrieving all employee Ids for login validation*/
	@Override
	public List<Long> getAllEmployeeIds() {
		String q="SELECT ebean.employeeId FROM EmployeeBean ebean";
		Query query=entitymanager.createQuery(q);
		return query.getResultList();
	}
	
	/*Retrieving all Employee Detail based on EmployeeId for the validation of Password
	 * and retrieving role if login details valid*/
	@Override
	public EmployeeBean RetrieveEmployeeDetail(long empId) {
		String q="FROM EmployeeBean ebean WHERE ebean.employeeId=:employeeId";
		TypedQuery<EmployeeBean> query=entitymanager.createQuery(q,EmployeeBean.class);
		query.setParameter("employeeId", empId);
		return query.getSingleResult();
	}

	/*Retrieving all training code based on Participant Id In feedback form*/
	@Override
	public List<Long> getAllTrainingCode(long participantId) 
	{
		String q="SELECT pbean.trainingCode FROM ParticipantEnrollmentBean pbean WHERE pbean.participantId=:participantId";
		Query query=entitymanager.createQuery(q);
		query.setParameter("participantId", participantId);
		return query.getResultList();	
	}
	/* Retrieving feedback given to a particular training*/
	@Override
	public List<FeedbackBean> getFeedbackByTrainingId(long trainingId) {
		String q="SELECT fbean FROM FeedbackBean fbean WHERE fbean.trainingCode=:trainId";
		Query query=entitymanager.createQuery(q);
		query.setParameter("trainId", trainingId);
		return query.getResultList();
	}
	/* Retrieving feedback given by a particular participant*/
	@Override
	public List<FeedbackBean> getFeedbackByParticipantId(long participantId) {
		String q="SELECT fbean FROM FeedbackBean fbean WHERE fbean.participantId=:partId";
		Query query=entitymanager.createQuery(q);
		query.setParameter("partId", participantId);
		return query.getResultList();
	}
	@Override
	public List<Long> getAllFeedBackParticipanIds() 
	{
		String q="SELECT fbean.participantId FROM FeedbackBean fbean";
		Query query=entitymanager.createQuery(q);
		return query.getResultList();
	}
}
