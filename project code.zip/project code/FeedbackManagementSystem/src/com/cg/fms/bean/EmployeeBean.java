package com.cg.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


	/* Name                                      Null?    Type
----------------------------------------- -------- --------------

EMPLOYEE_ID                               NOT NULL NUMBER(5)
EMPLOYEE_NAME                                      VARCHAR2(50)
ROLE                                               VARCHAR2(20)
SKILL_SET                                          VARCHAR2(200)
PASSWORD                                           VARCHAR2(20)
*/
@Entity
@Table(name="EMPLOYEE_MASTER")
public class EmployeeBean 
{
	@Id
	@Column(name="EMPLOYEE_ID")
	@NotNull(message="Please select Employee ID")
	private Long employeeId;
	@Column(name="EMPLOYEE_NAME")
	private String employeeName;
	@Column(name="PASSWORD")
	private String password;
	@Column(name="ROLE")
	private String role;
	@Column(name="SKILL_SET")
	private String skillSet;

	
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}	
	
}
