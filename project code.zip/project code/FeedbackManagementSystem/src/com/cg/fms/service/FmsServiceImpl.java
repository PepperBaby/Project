package com.cg.fms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.dao.IFmsDao;



@Service("fmsservice")
@Transactional
public class FmsServiceImpl implements IFmsService
{
	@Autowired
	IFmsDao fmsdao;

	@Override
	public boolean validateFeedback(long trainingId, long participantId) 
	{
		List<Long> tCode=fmsdao.validateGetAllFeedBackTrainingIds();
		List<Long> pCode=fmsdao.validateGetAllFeedBackParticipanIds(trainingId);

		for(long tcode:tCode)
		{
			for(long pcode:pCode)
			{
				if(tcode==trainingId && pcode==participantId)
				{
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public FeedbackBean insertFeedbackDetail(FeedbackBean feedback) {

		return fmsdao.insertFeedback(feedback);
	}

	/**Retrieving all employee Ids for login validation**/
	@Override
	public List<Long> getAllEmployeeIds() {

		return fmsdao.getAllEmployeeIds();
	}

	@Override
	public EmployeeBean RetrieveEmployeeDetail(long empId) 
	{
		return fmsdao.RetrieveEmployeeDetail(empId);
	}

	/**Retrieving all training code based on Participant Id In feedback form**/
	@Override
	public List<Long> getAllTrainingCode(long participantId) 
	{		
		return fmsdao.getAllTrainingCode(participantId);
	}

	@Override
	public List<FeedbackBean> getFeedbackByTrainingId(long trainingId) {
		return fmsdao.getFeedbackByTrainingId(trainingId);
	}

	@Override
	public List<FeedbackBean> getFeedbackByParticipantId(long participantId) {
		return fmsdao.getFeedbackByParticipantId(participantId);
	}

	@Override
	public List<Long> getAllFeedBackTrainingIds() {
		return fmsdao.validateGetAllFeedBackTrainingIds();
	}

	@Override
	public List<Long> getAllFeedBackParticipanIds() {
		return fmsdao.getAllFeedBackParticipanIds();
	}
	



}


