package com.cg.fms.service;

import java.util.List;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;

public interface IFmsService
{
	
	boolean validateFeedback(long trainingId,long participantId);
	FeedbackBean insertFeedbackDetail(FeedbackBean feedback);
	List<Long> getAllEmployeeIds();
	EmployeeBean RetrieveEmployeeDetail(long empId);
	List<Long> getAllTrainingCode(long participantId);
	List<FeedbackBean> getFeedbackByTrainingId(long trainingId);
	List<FeedbackBean> getFeedbackByParticipantId(long participantId);
	List<Long> getAllFeedBackTrainingIds();
	List<Long> getAllFeedBackParticipanIds();
}
